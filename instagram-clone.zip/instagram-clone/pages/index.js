import Navbar from "../components/Navbar";
import Stories from "../components/Stories";
import Post from "../components/Post";
import BottomNav from "../components/BottomNav";

export default function Home() {
  return (
    <div className="bg-gray-100 min-h-screen">
      <Navbar />
      <main className="max-w-xl mx-auto pb-20">
        <Stories />
        <Post />
        <Post />
        <Post />
      </main>
      <BottomNav />
    </div>
  );
}
