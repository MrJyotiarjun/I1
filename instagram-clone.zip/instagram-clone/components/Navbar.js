export default function Navbar() {
  return (
    <div className="bg-white border-b shadow-sm sticky top-0 z-50">
      <div className="max-w-xl mx-auto px-4 py-2 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Instagram</h1>
        <div className="space-x-4">
          <button>+</button>
          <button>❤️</button>
          <button>✉️</button>
        </div>
      </div>
    </div>
  );
}
