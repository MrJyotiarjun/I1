export default function Stories() {
  const users = Array.from({ length: 10 }, (_, i) => `user${i + 1}`);

  return (
    <div className="bg-white border-b p-3 flex overflow-x-scroll scrollbar-hide space-x-4">
      {users.map((user, idx) => (
        <div key={idx} className="flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-yellow-400 to-pink-600 p-1">
            <div className="bg-white rounded-full w-full h-full p-1">
              <div className="bg-gray-300 w-full h-full rounded-full" />
            </div>
          </div>
          <p className="text-xs">{user}</p>
        </div>
      ))}
    </div>
  );
}
