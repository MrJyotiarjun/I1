export default function Post() {
  return (
    <div className="bg-white my-4 rounded shadow-sm">
      <div className="flex items-center p-3">
        <div className="w-10 h-10 bg-gray-300 rounded-full"></div>
        <p className="ml-3 font-semibold">username</p>
      </div>
      <div className="bg-gray-200 w-full h-80" />
      <div className="p-3 space-y-2">
        <div className="flex space-x-4 text-xl">
          <button>❤️</button>
          <button>💬</button>
          <button>📤</button>
        </div>
        <p className="text-sm"><strong>username</strong> Awesome photo!</p>
      </div>
    </div>
  );
}
